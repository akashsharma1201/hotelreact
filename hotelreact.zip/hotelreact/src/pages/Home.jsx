import React, { useEffect, useState } from 'react'
import Hotelcard from '../components/Hotelcard'
import { CgSandClock } from "react-icons/cg"
import axios from 'axios'
import { useDispatch, useSelector } from "react-redux"
import { getPropertyAction } from '../redux/features/propertySlice'

const Home = () => {

    const [location, setLocation] = useState("new york")
    const [endindIndex, setEndingIndex] = useState(6)
    const property = useSelector((state) => (state?.property?.data))
    const dispatch = useDispatch()


    const getData = async () => {
        dispatch(getPropertyAction())
    }

    useEffect(() => {
        getData()
      
    }, [endindIndex])

    const loagMore = () => {
        setEndingIndex(endindIndex + 3)
    }

    
    return (
        <>
            <div className="container">
                <div className="row">
                    <div className="col-md-6 mx-auto">
                        <div className="listedproperty mx-auto">
                            <h3>Featured Listed Property</h3>
                            <p>Real estate can be bought, sold, leassed, or rented, and can be a valuable investment opportunity. The value of real state can be ...

                            </p>
                        </div>

                    </div>
                </div>
                <div className="row">
                    {/* NAV TAV */}
                    <ul className="nav nav-pills mb-3 gap-2" id="pills-tab" role="tablist">
                        <li className="nav-item" role="presentation">
                            <button onClick={() => setLocation("new york")} className="nav-link active" id="pills-home-tab" data-bs-toggle="pill" data-bs-target="#pills-home" type="button" role="tab" aria-controls="pills-home" aria-selected="true">New York</button>
                        </li>
                        <li className="nav-item" role="presentation">
                            <button onClick={() => setLocation("mumbai")} className="nav-link" id="pills-profile-tab" data-bs-toggle="pill" data-bs-target="#pills-profile" type="button" role="tab" aria-controls="pills-profile" aria-selected="false">Mumbai</button>
                        </li>
                        <li className="nav-item" role="presentation">
                            <button onClick={() => setLocation("paris")} className="nav-link" id="pills-contact-tab" data-bs-toggle="pill" data-bs-target="#pills-contact" type="button" role="tab" aria-controls="pills-contact" aria-selected="false">Paris</button>
                        </li>
                        <li className="nav-item" role="presentation">
                            <button onClick={() => setLocation("landon")} className="nav-link" id="pills-contact-tab" data-bs-toggle="pill" data-bs-target="#pills-landon" type="button" role="tab" aria-controls="pills-contact" aria-selected="false">London</button>
                        </li>

                    </ul>
                    {
                        property?.length > 0 ?

                            <div className="tab-content" id="pills-tabContent">
                                <div className="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab" tabindex="0">
                                    <div className="row">
                                        {
                                            property?.filter((el) => el.location == location)?.slice(0, endindIndex)?.map((item, index) => {
                                                return (
                                                    <Hotelcard hotel={item} key={index} />
                                                )
                                            })
                                        }
                                    </div>

                                </div>
                                <div className="tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab" tabindex="0">
                                    <div className="row">
                                        {
                                            property?.filter((el) => el.location == location)?.slice(0, endindIndex)?.map((item, index) => {
                                                return (
                                                    <Hotelcard hotel={item} key={index} />
                                                )
                                            })
                                        }
                                    </div>
                                </div>
                                <div class="tab-pane fade" id="pills-contact" role="tabpanel" aria-labelledby="pills-contact-tab" tabindex="0">
                                    <div className="row">
                                        {
                                            property?.filter((el) => el.location == location)?.slice(0, endindIndex)?.map((item, index) => {
                                                return (
                                                    <Hotelcard hotel={item} key={index} />
                                                )
                                            })
                                        }
                                    </div>
                                </div>
                                <div class="tab-pane fade" id="pills-landon" role="tabpanel" aria-labelledby="pills-disabled-tab" tabindex="0">
                                    <div className="row">
                                        {
                                            property?.filter((el) => el.location == location)?.slice(0, endindIndex)?.map((item, index) => {
                                                return (
                                                    <Hotelcard hotel={item} key={index} />
                                                )
                                            })
                                        }
                                    </div>
                                </div>
                            </div> : <h3>LOADING...</h3>
                    }

                    <button className='load-more' onClick={loagMore}> <CgSandClock className='text-white' />Load More</button>

                    {/* REBDER CARD */}
                </div>
            </div>
        </>
    )
}

export default Home