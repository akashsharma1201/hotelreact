import React from 'react'
import { useParams } from "react-router-dom"
import {useState ,useEffect}  from "react"
import { VscLocation } from "react-icons/vsc"
import { BsFillBuildingsFill, BsArrowsMove } from "react-icons/bs"
import { BiSolidBed } from 'react-icons/bi'
import { HiOutlineHeart } from "react-icons/hi"
import { FaBath } from "react-icons/fa"
import axios from 'axios'

const PropertyDetail = () => {
    const [hotel , setHotel]=useState({})
    const { id } = useParams()
    

    const getOneProperty =async () => {
        try {
            const result = await axios(`http://localhost:8000/hotels/${id}`)
            setHotel(result.data)
        } catch (error) {
            console.log(error)
        }
    }

    useEffect(() => {
     getOneProperty()
    }, []);
    return (
        <div className='container'>
            <div className="row">
                <div className="col-md-4 mt-3">
                    <div div className="car-card" >
                        <div className='car-image-wrapper'>
                        <img src={ hotel?.url } className='img-fluid' alt="" />

                            <div className='img-icons'>
                                <span>For Rent</span>
                                <button className='wishlist'><HiOutlineHeart /></button>
                            </div>

                        </div>
                        <div className='car-text-body'>
                            <div className="popular">
                                <h3> Popular</h3>
                            </div>
                            <div className='car-title-and-year'>
                                <h6> <VscLocation /> 8852 Green RD.</h6>
                                <h5>{hotel?.title}</h5>
                                { }
                            </div>
                            <div className='car-feature'>
                                <div className="row">
                                    <div className="col-3">
                                        <div className="title d-flex flex-column align-items-center"> < BsFillBuildingsFill />
                                            <span>{hotel?.rooms} Rooms</span></div>

                                    </div>
                                    <div className="col-3">
                                        <div className="title d-flex flex-column align-items-center"> < BiSolidBed />
                                            <span> {hotel.bed} Bed</span></div>
                                    </div>
                                    <div className="col-3">
                                        <div className="title d-flex flex-column align-items-center"> < FaBath />
                                            <span>{hotel.bath} Bath</span></div>
                                    </div>
                                    <div className="col-3">
                                        <div className="title d-flex flex-column align-items-center"> < BsArrowsMove />
                                            <span>{hotel?.area}.</span></div>
                                    </div>
                                </div>
                            </div>
                            <div className='card-bottom'>
                                <h4>
                                    ${hotel?.price} <span>/ month</span>
                                </h4>
                                <div className="card-buttons">
                                    {/* <button className='wishlist'><HiOutlineHeart /></button> */}
                                    <button className='rent-now'>Read more</button>
                                </div>
                            </div>
                        </div>

                    </div >


                </div>
            </div>
        </div>
    )
}

export default PropertyDetail