import { combineReducers } from 'redux'
import propertyReducer from "./features/propertySlice"
export const reducerRoot = combineReducers({
    // here we will be adding reducers
    property : propertyReducer
})