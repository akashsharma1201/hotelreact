import { createSlice ,createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";






export const getPropertyAction = createAsyncThunk("property/get", async (thunkAPI) => {
    try {
        const result = await axios("http://localhost:8000/hotels")
        return result.data
    } catch (error) {
        console.log(thunkAPI)
    }
})

const initialState = {
    data: [],
    loading: false

}

const propertySlice = createSlice({
    name: "propertyslice",
    initialState: initialState,
    reducers: {},
    extraReducers: (builder) => {
        builder
            .addCase(getPropertyAction.pending, (state) => {
                state.loading = true
            })
            .addCase(getPropertyAction.fulfilled, (state, action) => {
                state.loading = false
                state.data=(action.payload)
            })
            .addCase(getPropertyAction.rejected, (state, action) => {
                state.loading = false
                state.error = "Something  Wrong"
            })
    }
})


export default propertySlice.reducer