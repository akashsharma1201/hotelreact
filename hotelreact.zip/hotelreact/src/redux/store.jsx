import { configureStore } from '@reduxjs/toolkit'

import { reducerRoot } from './rootReducers'

const store = configureStore({
  reducer : reducerRoot
})

export default store